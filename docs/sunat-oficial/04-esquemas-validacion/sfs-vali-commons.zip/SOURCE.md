﻿# sfs-vali-commons

Source: https://ww2.sunat.gob.pe/facturador/Archivos_actualizacion_sfs.zip
Extracted path: sunat_archivos/sfs/VALI/commons/{error,cpe,StringTemplates.xsl}
Fetched: 2026-09-22
Notes:
- Omits commons/xsd and commons/xsl (not required for ValidaExprRegFactura includes).
- Adds commons/cpe/datos/dat_fechas.xml stub (missing from update zip; see file comment).
